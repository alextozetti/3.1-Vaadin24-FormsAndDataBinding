Copyright (C) Vaadin Ltd - All Rights Reserved

Unauthorized copying or distributing of any file inside this folder, via any medium is strictly prohibited

Proprietary and confidential